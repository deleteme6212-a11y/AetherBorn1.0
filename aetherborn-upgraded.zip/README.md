# Aetherborn — Upgraded HTML5 Build

This upgraded release includes pixel art sprites and chiptune audio, a title screen, companion, improved AI, particle effects,
multiple biomes visuals, and a full playable experience in the browser.

## How to run
Open `index.html` in a modern browser. No server required. For GitHub Pages, push to a repository and enable Pages on `main` branch.

## Files
- index.html
- css/style.css
- js/game-upgraded.js
- assets/*.png
- audio/*.wav

Enjoy!
