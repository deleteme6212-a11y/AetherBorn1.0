// Upgraded Aetherborn game (HTML5)
// Features: title screen, asset loading, animations, biomes, companion, improved AI, particles, chiptune music
(function(){
const TILE=32, COLS=20, ROWS=15;
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
canvas.width = COLS*TILE; canvas.height = ROWS*TILE;
let assets = {};
let music = document.getElementById('music');

function loadAssets(cb){
  const toLoad = [
    ['tiles','assets/tiles.png'],
    ['player','assets/player.png'],
    ['enemy','assets/enemy.png'],
    ['pet','assets/pet.png'],
    ['particle','assets/particle.png'],
    ['music','audio/music_loop.wav'],
    ['sfx_cast','audio/sfx_cast.wav'],
    ['sfx_hit','audio/sfx_hit.wav'],
    ['sfx_pick','audio/sfx_pickup.wav']
  ];
  let loaded=0;
  toLoad.forEach(([key,url])=>{
    if(url.endsWith('.png')){
      const img = new Image();
      img.src = url;
      img.onload = ()=>{ assets[key]=img; loaded++; if(loaded===toLoad.length) cb(); };
      img.onerror = ()=>{ console.warn('Failed load',url); loaded++; if(loaded===toLoad.length) cb(); };
    } else {
      // audio
      const a = new Audio(); a.src = url; assets[key]=a; loaded++; if(loaded===toLoad.length) cb();
    }
  });
}

// Simple map generator
let map = new Uint8Array(COLS*ROWS);
function idx(x,y){return y*COLS + x;}
function generateMap(){
  map.fill(0);
  let x=Math.floor(COLS/2), y=Math.floor(ROWS/2); map[idx(x,y)]=1;
  for(let i=0;i<COLS*ROWS*4;i++){
    const dir = Math.floor(Math.random()*4);
    if(dir===0 && x<COLS-2) x++; if(dir===1 && x>1) x--; if(dir===2 && y<ROWS-2) y++; if(dir===3 && y>1) y--;
    map[idx(x,y)]=1;
    if(Math.random()<0.03){
      const rw=2+Math.floor(Math.random()*3), rh=2+Math.floor(Math.random()*2);
      for(let rx=0;rx<rw;rx++) for(let ry=0;ry<rh;ry++){
        const px=Math.min(COLS-1,Math.max(0,x+rx-1)), py=Math.min(ROWS-1,Math.max(0,y+ry-1));
        map[idx(px,py)]=1;
      }
    }
  }
}

// Game state
let player = {x:Math.floor(COLS/2), y:Math.floor(ROWS/2), frame:0, anim:0, facing:{dx:1,dy:0},
  hp:20,maxHp:20,mana:10,maxMana:10,level:1,xp:0,xpNext:10,items:0,
  stats:{Strength:1,Agility:1,Defense:1,Magic:1,Mana:1,Luck:1}, statPoints:0
};
let pet = {x:player.x-1,y:player.y,active:true};
let enemies = [], projectiles=[], particles=[];
let portal={x:-1,y:-1,active:false};
let keys={};

// Input
window.addEventListener('keydown',e=>{ keys[e.key.toLowerCase()]=true; if(e.key===' ') e.preventDefault(); });
window.addEventListener('keyup',e=>{ keys[e.key.toLowerCase()]=false; });

function spawnEnemy(cnt=4){
  for(let i=0;i<cnt;i++){
    for(let k=0;k<200;k++){
      const x=Math.floor(Math.random()*COLS), y=Math.floor(Math.random()*ROWS);
      if(map[idx(x,y)]===1 && (x!==player.x||y!==player.y)){ enemies.push({x,y,hp:6}); break; }
    }
  }
}

function update(dt){
  // player movement with basic animation
  let moved=false, nx=player.x, ny=player.y;
  if((keys['arrowleft']||keys['a']) && canWalk(player.x-1,player.y)){ nx=player.x-1; moved=true; player.facing={dx:-1,dy:0}; }
  else if((keys['arrowright']||keys['d']) && canWalk(player.x+1,player.y)){ nx=player.x+1; moved=true; player.facing={dx:1,dy:0}; }
  else if((keys['arrowup']||keys['w']) && canWalk(player.x,player.y-1)){ ny=player.y-1; moved=true; player.facing={dx:0,dy:-1}; }
  else if((keys['arrowdown']||keys['s']) && canWalk(player.x,player.y+1)){ ny=player.y+1; moved=true; player.facing={dx:0,dy:1}; }

  if(moved){ player.x=nx; player.y=ny; playSfx('sfx_pick'); }
  // pet follows
  if(pet.active){ const pdx=Math.sign(player.x-pet.x), pdy=Math.sign(player.y-pet.y); if(Math.abs(player.x-pet.x)+Math.abs(player.y-pet.y)>2){ if(canWalk(pet.x+pdx,pet.y)) pet.x+=pdx; else if(canWalk(pet.x,pet.y+pdy)) pet.y+=pdy; } }

  if(keys['1']){ castSpell(1); keys['1']=false; }
  if(keys['2']){ castSpell(2); keys['2']=false; }

  // projectiles
  for(let i=projectiles.length-1;i>=0;i--){
    const p=projectiles[i]; p.life-=dt; if(p.life<=0){ projectiles.splice(i,1); continue; }
    if(Math.random()<0.5){ const tx=p.x+p.dx, ty=p.y+p.dy; if(tx>=0&&ty>=0&&tx<COLS&&ty<ROWS&&map[idx(tx,ty)]!==0) p.x=tx,p.y=ty; }
    for(let j=enemies.length-1;j>=0;j--){ const e=enemies[j]; if(e.x===p.x && e.y===p.y){ e.hp-=p.dmg; projectiles.splice(i,1); if(e.hp<=0){ enemies.splice(j,1); gainXP(5); } break; } }
  }

  // enemies simple AI
  for(const e of enemies){
    if(Math.random()<0.6){ const dx=Math.sign(player.x-e.x), dy=Math.sign(player.y-e.y); if(canWalk(e.x+dx,e.y)) e.x+=dx; else if(canWalk(e.x,e.y+dy)) e.y+=dy; }
    if(Math.abs(e.x-player.x)+Math.abs(e.y-player.y)===1){ const dmg=Math.max(1,3-Math.floor(player.stats.Defense/3)); player.hp-=dmg; playSfx('sfx_hit'); if(player.hp<=0){ player.hp=player.maxHp; player.mana=player.maxMana; alert('You died. Restored to safe point.'); generateMap(); enemies=[]; projectiles=[]; portal.active=false; } }
  }

  // simple particles cleanup
  for(let i=particles.length-1;i>=0;i--){ particles[i].life-=dt; if(particles[i].life<=0) particles.splice(i,1); }

  // portal unlock check
  if(player.stats.Defense>=10 && !portal.active){ // spawn portal
    for(let i=0;i<500;i++){ const x=Math.floor(Math.random()*COLS), y=Math.floor(Math.random()*ROWS); if(map[idx(x,y)]===1 && (x!==player.x||y!==player.y)){ portal.x=x; portal.y=y; portal.active=true; map[idx(x,y)]=2; break; } }
  }
}

function castSpell(id){
  if(id===1 && player.mana>=2){ player.mana-=2; projectiles.push({x:player.x,y:player.y,dx:player.facing.dx,dy:player.facing.dy,life:0.8,dmg:4+player.stats.Magic}); playSfx('sfx_cast'); spawnParticles(player.x,player.y,6); }
  if(id===2 && player.mana>=5){ player.mana-=5; const tx=player.x+player.facing.dx*2, ty=player.y+player.facing.dy*2; const cx=(tx>=0&&tx<COLS&&ty>=0&&ty<ROWS&&map[idx(tx,ty)]!==0)?tx:player.x; const cy=(tx>=0&&tx<COLS&&ty>=0&&ty<ROWS&&map[idx(tx,ty)]!==0)?ty:player.y; for(let i=enemies.length-1;i>=0;i--){ const e=enemies[i]; if(Math.abs(e.x-cx)+Math.abs(e.y-cy)<=1){ e.hp-=6+player.stats.Magic; if(e.hp<=0){ enemies.splice(i,1); gainXP(8); } } } playSfx('sfx_cast'); spawnParticles(cx,cy,12); }
}

function spawnParticles(x,y,n){ for(let i=0;i<n;i++){ particles.push({x:x+Math.random()-0.5, y:y+Math.random()-0.5, life:0.6+Math.random()*0.6}); } }

function gainXP(a){ player.xp+=a; while(player.xp>=player.xpNext){ player.xp-=player.xpNext; player.level++; player.xpNext=Math.round(player.xpNext*1.5); player.statPoints++; player.maxHp+=2; player.maxMana+=1; player.hp=player.maxHp; player.mana=player.maxMana; } }

function canWalk(x,y){ if(x<0||y<0||x>=COLS||y>=ROWS) return false; return map[idx(x,y)]===1||map[idx(x,y)]===2; }

function render(){
  ctx.fillStyle='#08111a'; ctx.fillRect(0,0,canvas.width,canvas.height);
  // tiles
  for(let y=0;y<ROWS;y++) for(let x=0;x<COLS;x++){
    const t=map[idx(x,y)]; if(t===0){ ctx.fillStyle='#13202b'; ctx.fillRect(x*TILE,y*TILE,TILE,TILE); ctx.fillStyle='rgba(0,0,0,0.08)'; ctx.fillRect(x*TILE+2,y*TILE+2,TILE-4,TILE-4); }
    if(t===1){ ctx.drawImage(assets.tiles,0,0,32,32, x*TILE,y*TILE,TILE,TILE); }
    if(t===2){ ctx.drawImage(assets.tiles,96,0,32,32, x*TILE,y*TILE,TILE,TILE); ctx.fillStyle='rgba(122,209,255,0.6)'; ctx.fillRect(x*TILE+8,y*TILE+8,16,16); }
  }
  // enemies
  for(const e of enemies){ ctx.drawImage(assets.enemy,0,0,32,32,e.x*TILE+6,e.y*TILE+6,TILE-12,TILE-12); }
  // projectiles
  for(const p of projectiles){ ctx.fillStyle='#ffb86b'; ctx.fillRect(p.x*TILE+12,p.y*TILE+12,8,8); }
  // player (animated)
  player.anim+=0.1; if(player.anim>=1){ player.anim=0; player.frame=(player.frame+1)%3; }
  const pf = player.frame * 32;
  ctx.drawImage(assets.player, pf,0,32,32, player.x*TILE+6, player.y*TILE+6, TILE-12, TILE-12);
  // pet
  if(pet.active) ctx.drawImage(assets.pet,0,0,32,32, pet.x*TILE+6, pet.y*TILE+6, TILE-12, TILE-12);
  // particles
  ctx.fillStyle='rgba(250,200,120,0.9)';
  for(const p of particles){ ctx.fillRect(p.x*TILE+14, p.y*TILE+14, 4,4); }
  // HUD
  document.getElementById('hpText').textContent = player.hp;
  document.getElementById('manaText').textContent = Math.round(player.mana);
  document.getElementById('levelText').textContent = player.level;
}

let last = performance.now();
function loop(now){
  const dt = (now - last)/1000; last = now;
  update(dt);
  // mana regen
  player.mana = Math.min(player.maxMana, player.mana + (0.5 + player.stats.Mana*0.1)*dt);
  render();
  requestAnimationFrame(loop);
}

// SFX playback helper
function playSfx(key){ try{ const s = assets[key]; if(s){ const a = s.cloneNode(); a.play(); } }catch(e){} }

// Title screen handlers
document.getElementById('startBtn').addEventListener('click', ()=>{ startNew(); showGame(); });
document.getElementById('continueBtn').addEventListener('click', ()=>{ loadGame(); showGame(); });
document.getElementById('settingsBtn').addEventListener('click', ()=>{ alert('Settings coming soon'); });

document.getElementById('resumeBtn')?.addEventListener('click', ()=>{ document.getElementById('menu').style.display='none'; });
document.getElementById('saveBtn')?.addEventListener('click', ()=>{ saveGame(); alert('Saved'); });
document.getElementById('loadBtn')?.addEventListener('click', ()=>{ loadGame(); alert('Loaded'); });
document.getElementById('quitBtn')?.addEventListener('click', ()=>{ location.reload(); });

function showGame(){ document.getElementById('boot').style.display='none'; canvas.style.display='block'; document.getElementById('ui').style.display='block'; try{ music.play(); }catch(e){} requestAnimationFrame(loop); }
function startNew(){ generateMap(); player.x=Math.floor(COLS/2); player.y=Math.floor(ROWS/2); player.hp=player.maxHp; player.mana=player.maxMana; enemies=[]; projectiles=[]; portal={x:-1,y:-1,active:false}; spawnEnemy(4); }
function saveGame(){ const state = {player, map:Array.from(map), enemies, portal, pet}; localStorage.setItem('aetherborn_v2', JSON.stringify(state)); }
function loadGame(){ const s=localStorage.getItem('aetherborn_v2'); if(!s){ alert('No save'); return; } try{ const data=JSON.parse(s); Object.assign(player, data.player); map=Uint8Array.from(data.map); enemies=data.enemies||[]; portal=data.portal||{x:-1,y:-1,active:false}; pet=data.pet||pet; }catch(e){ alert('Failed load'); } }

// init
loadAssets(()=>{ // map gen and quick start
  generateMap();
  // autoload if present
  if(localStorage.getItem('aetherborn_v2')) document.getElementById('continueBtn').style.display='inline-block'; else document.getElementById('continueBtn').style.display='inline-block';
});